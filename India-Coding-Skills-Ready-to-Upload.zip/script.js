const defaultHTML = `<h1>Welcome To India Coding Skills 🇮🇳</h1>
<p>Build your own website here.</p>`;

const defaultCSS = `body {
  font-family: Arial, sans-serif;
  text-align: center;
  padding: 50px;
}
h1 { color: #ff6600; }`;

const defaultJS = `console.log("India Coding Skills is working!");`;

function showEditor(type) {
  document.querySelectorAll(".editor-box").forEach(el => el.classList.remove("active-editor"));
  document.querySelectorAll(".tab").forEach(el => el.classList.remove("active"));

  document.getElementById(type + "Editor").classList.add("active-editor");
  document.getElementById(type + "Tab").classList.add("active");
}

function runWebsite() {
  const html = document.getElementById("htmlCode").value;
  const css = document.getElementById("cssCode").value;
  const js = document.getElementById("jsCode").value;
  const frame = document.getElementById("previewFrame");
  const status = document.getElementById("previewStatus");

  if (!html.trim() && !css.trim() && !js.trim()) {
    alert("⚠️ Pehle code enter karo!");
    return;
  }

  const fullDocument = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>${css.replace(/<\/style/gi, "<\\/style")}</style>
</head>
<body>
${html}
<script>
try { ${js.replace(/<\/script/gi, "<\\/script")} } catch(e) { console.error(e); }
<\/script>
</body>
</html>`;

  frame.srcdoc = fullDocument;
  status.textContent = "LIVE";
  status.style.color = "#20e070";
}

function resetEditor() {
  if (!confirm("⚠️ Kya aap saara code reset karna chahte ho?")) return;

  document.getElementById("htmlCode").value = defaultHTML;
  document.getElementById("cssCode").value = defaultCSS;
  document.getElementById("jsCode").value = defaultJS;

  document.getElementById("previewFrame").srcdoc = "";
  document.getElementById("previewStatus").textContent = "Ready";
  showEditor("html");
}

function downloadWebsite() {
  const html = document.getElementById("htmlCode").value;
  const css = document.getElementById("cssCode").value;
  const js = document.getElementById("jsCode").value;

  if (!html.trim() && !css.trim() && !js.trim()) {
    alert("⚠️ Pehle website banao!");
    return;
  }

  const website = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Website</title>
<style>${css}</style>
</head>
<body>
${html}
<script>${js.replace(/<\/script/gi, "<\\/script")}<\/script>
</body>
</html>`;

  const blob = new Blob([website], {type:"text/html;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "India-Coding-Skills-Website.html";
  document.body.appendChild(link);
  link.click();
  link.remove();

  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

document.addEventListener("DOMContentLoaded", () => {
  runWebsite();
});
